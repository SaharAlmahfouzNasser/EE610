ipImg = imread('child_grass.PNG');
DeltaT = 5;
grayImg = rgb2gray(ipImg);
%%%%%%%%%%%% Global Threshold %%%%%%%%%%%
IniT = (max(max(grayImg))-min(min(grayImg)))/2;
newT = IniT;
[rows cols]= size(grayImg);
totalPixels = rows*cols;
m1=0;
m2=0;
flag = 1;
while(flag == 1 | abs(IniT-newT)>DeltaT)
    SegImg = grayImg >= newT;
    flag = 0;
    m1=0;
    m2=0;
    for k=0:255
        m1 = m1+k*length(find(SegImg == 0 & grayImg ==k))/totalPixels;
        m2 = m2+k*length(find(SegImg == 1 & grayImg ==k))/totalPixels;
    end
    NewT = (m1+m2)/2;
end
figure;imshow(SegImg);title('global th');
%%%%%%%%%%%% Global Threshold %%%%%%%%%%%
%%%%%%%%%%%% Otsu Threshold %%%%%%%%%%%
P1 = zeros(1,256);
m = zeros(1,256);
mg =0;
 for k=0:255
        P1(k+1)= length(find(grayImg <=k))/totalPixels;
        mg = mg + k*length(find(grayImg ==k))/totalPixels;
        m(k+1) = mg;
 end
 Sigma = ((mg*P1-m).^2)./(P1.*(1-P1));
 [maxVal Loc]= max( Sigma)
 SegImg2 = grayImg >= (Loc-1);
 figure;imshow(SegImg2);title('otsu');
%%%%%%%%%%%% Otsu Threshold %%%%%%%%%%%
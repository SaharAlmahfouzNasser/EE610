function [Cnx, Csx, Cey, Cwy] = DiffusionCoef(DistMap)
% DiffusionCoef Summary of this function goes here
%   Detailed explanation goes here
 
Cnx = 0.5*(DistMap([2:end,end],:)+DistMap); % average in upward direction
Cey = 0.5*(DistMap(:,[2:end,end])+DistMap); % average in forward direction
Csx = 0.5*(DistMap([1,1:end-1],:)+DistMap); % average in downward direction
Cwy = 0.5*(DistMap(:,[1,1:end-1])+DistMap); % average in backward direction

end


function [Gnx, Gsx, Gey, Gwy] = GradientAll(IpImg)
% GradientAll Summary of this function goes here
%   Detailed explanation goes here
Gnx = IpImg([2:end,end],:)-IpImg; %f(x+1)-f(x): upward difference
Gey = IpImg(:,[2:end,end])-IpImg; %f(y+1)-f(y): forward difference
Gsx = IpImg-IpImg([1,1:end-1],:); %f(x)-f(x-1): downward difference
Gwy = IpImg-IpImg(:,[1,1:end-1]); %f(y)-f(y-1): backward difference

end


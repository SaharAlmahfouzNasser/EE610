function [ SegImg ] = OtsuThreshold(IpImg)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
[rows cols]= size(IpImg);
totalPixels = rows*cols;
P1 = zeros(1,256);
m = zeros(1,256);
mg =0;
 for k=0:255
        P1(k+1)= length(find(IpImg <=k))/totalPixels;
        mg = mg + k*length(find(IpImg ==k))/totalPixels;
        m(k+1) = mg;
 end
 Sigma = ((mg*P1-m).^2)./(P1.*(1-P1));
 [maxVal Loc]= max(Sigma)
 SegImg = (IpImg >= (Loc-1));
%  figure;imshow(SegImg);title('otsu');

end


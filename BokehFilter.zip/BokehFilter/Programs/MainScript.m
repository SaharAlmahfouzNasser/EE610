close all;
clear all;
%%%%%%%%% Read Input Image %%%%%%%
RGBImg = imread('child_grass.PNG');
OrigImg = double(rgb2gray(RGBImg));
[rows cols] = size(OrigImg)
mask = zeros(rows, cols);
initialr = round(rows/6);
%initialc = round(cols/8);
mask(initialr:end-initialr,initialr:end-initialr) = 1;
%figure; imshow(mask);title('Initial mask')
ItrNo=100;
SegImg1 = activecontour(OrigImg,mask,ItrNo);
SegImg2 = GlobalThreshold(OrigImg);
SegImg3 = OtsuThreshold(OrigImg);
figure;
subplot(2,2,1);imshow(uint8(OrigImg));title('Original Image');
subplot(2,2,2);imshow(SegImg1);title({'Segmentaion using Chan-Vase iterations=100'});
subplot(2,2,3);imshow(SegImg2);title('Segmentation using global threshold');
subplot(2,2,4);imshow(SegImg3);title('Segmentaion using Otsu method');

distMap=double(bwdist(SegImg1));
distMap=sqrt(distMap.^2+0.001);
distMap=distMap/max(distMap(:));
distMap=distMap./(max(max(distMap)));
figure, imshow(distMap)
title("the distance map")

[Cnx, Csx, Cey, Cwy] = DiffusionCoef(distMap); % Computation of diffusion coefficient  
Iterations = 50;
initdt=0.3;
dt = initdt.*distMap; % time step
FinalImg = OrigImg;
BlurrImg = OrigImg;
for j = 0:Iterations-1
    [Gnx, Gsx, Gey, Gwy] = GradientAll(FinalImg);
    L = (Cnx.*Gnx-Csx.*Gsx)+(Cey.*Gey-Cwy.*Gwy);
    FinalImg = FinalImg + dt.*L;
    [Gnx, Gsx, Gey, Gwy] = GradientAll(BlurrImg);
    L = (Gnx-Gsx)+(Gey-Gwy);
    BlurrImg = BlurrImg + initdt.*L;
end

subplot(2,2,1),subimage(OrigImg./max(max(OrigImg)));axis off;
title('Original Image');
subplot(2,2,2), subimage(SegImg1);axis off;
title({'Segmentaion using Chan-Vese iteration=',ItrNo}');
subplot(2,2,3), subimage(BlurrImg./max(max(BlurrImg)));axis off;
title({'Isotropic Diffusion without using distance map'});
subplot(2,2,4), subimage(FinalImg./max(max(FinalImg)));axis off;
title({'Isotropic Diffusion  considering distance map,iterations=',Iterations,'time step=',initdt})
figure;subplot(2,1,1);imshow(uint8(OrigImg));title('Original Image');
subplot(2,1,2), subimage(FinalImg./max(max(FinalImg)));axis off;
title({'Isotropic Diffusion, N=100, Step=0.3'})

lpfmask = ones(15,15);
lpfmask=lpfmask/(15*15);
SmoothImage = conv2(OrigImg,lpfmask);
SmoothImage = SmoothImage(8:rows+7,8:cols+7);
figure;subplot(1,3,1);imshow(uint8(SmoothImage.*abs(1-SegImg1)));title('Blurred Background');
subplot(1,3,2);imshow(uint8(OrigImg.*abs(SegImg1)));title('Intact Foreground');
fi = SmoothImage.*abs(1-SegImg1) + OrigImg.*abs(SegImg1);
subplot(1,3,3);imshow(uint8(fi));title('Result');
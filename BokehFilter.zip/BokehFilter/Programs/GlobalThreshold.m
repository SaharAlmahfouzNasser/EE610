function [SegImg] = GlobalThreshold(IpImg )
% GlobalThreshold Summary of this function goes here
%   Detailed explanation goes here
DeltaT = 5;
grayImg = IpImg;
%%%%%%%%%%%% Global Threshold %%%%%%%%%%%
IniT = (max(max(grayImg))-min(min(grayImg)))/2;
newT = IniT;
[rows cols]= size(grayImg);
totalPixels = rows*cols;
m1=0;
m2=0;
flag = 1;
while(flag == 1 | abs(IniT-newT)>DeltaT)
    SegImg = (grayImg >= newT);
    flag = 0;
    m1=0;
    m2=0;
    for k=0:255
        % m1:Mean of background
        m1 = m1+k*length(find(SegImg == 0 & grayImg ==k))/totalPixels;
        % m2: Mean of foreground
        m2 = m2+k*length(find(SegImg == 1 & grayImg ==k))/totalPixels;
    end
    NewT = (m1+m2)/2;
end
%figure;imshow(SegImg);title('global th');
%%%%%%%%%%%% Global Threshold %%%%%%%%%%%
end


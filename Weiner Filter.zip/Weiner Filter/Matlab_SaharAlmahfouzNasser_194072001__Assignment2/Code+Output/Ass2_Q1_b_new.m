% reading the input image
Input_Image=imread('image.png');
% convert the input image to gray image
Input_Image=rgb2gray(Input_Image);
Input_Image=double(Input_Image);
% displaying the input image
figure
subplot(221),imagesc(Input_Image)
title('Input Image'),colormap('gray'),daspect([1 1 1])
%Processing in the frequency domain
[width,height]=size(Input_Image);
Input_Image_freq=zeros(size(Input_Image));
% multipling the input image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width
    for j=1:height
       k=i+j;
       Input_Image_freq(i,j)=Input_Image(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(Input_Image_freq);
% the magnitude of fourier transform
Mag=abs(F);
Sf=(Mag).^2;
% using log function for better visualization
subplot(222),imagesc(log(Mag))
title('Magnitude of fourier transform of the original image'),colormap('gray'),daspect([1 1 1])
% Generating the degradation function in frequency domain
m=width/2;
n=height/2;
H_d=zeros(size(F));
conj_H_d=zeros(size(F));
for u=1:width
    for v=1:height
        H_d(u,v)=exp(-0.0025*((u-m)^2+(v-n)^2)^(5/6));
        %computing the conjocate of the degredation function
        conj_H_d(u,v)=conj(H_d(u,v));
    end
end
Mag_H_d=abs(H_d);
% displaying the degradation function
subplot(223),imagesc(log(Mag_H_d))
title('The Magnitude of Degredation Function'),colormap('gray'),daspect([1 1 1])
% Degrading the input image with the given degradation function
G=F.*H_d;
G=ifftshift(G);
% computing the inverse fourier transform
g=ifft2(G);
%extracting the real part
g=real(g);
subplot(224),imagesc(g)
title('The degraded image before adding the noise'),colormap('gray'),daspect([1 1 1])
% Maximum Intensity of the input image
Max=max(max(Input_Image));
% Adding the gaussian noise

% Intialization of relative root mean square error vectors
RRMSE_g_Input_vector=zeros(1,6);
RRMSE_Filtered_image_Input_vector=zeros(1,6);
counter=1;
for s=1:5:26
%sigma is the standard deviation of the gaussian noise 
sigma=((s-1)/100)*Max;
Noise=sigma*randn(size(g));
Noisy_g=g+Noise;
Noisy_g=uint8(Noisy_g);
% Displaying the degraded image after adding the noise
figure
subplot(221),imagesc(Noisy_g)
title(['Degraded Image after adding gaussian noise with std=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])
% computing fourier transform of the noise
N=fft2(Noise);
% the magnitude of fourier transform
Mag_N=abs(N);
Sn=(Mag_N).^2;
% inverse of SNR
Sn_Sf=Sn./Sf;
%Computing fourier transform of the degraded image
[w,h]=size(Noisy_g);
g_n=zeros(size(Noisy_g));
% multipling g by -1^(i+j) in order to center the fourier 
%transform
for i=1:w
    for j=1:h
       k=i+j;
       g_n(i,j)=g(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
G=fft2(g_n);
[W,H]=size(G);
% the magnitude of fourier transform
Mag_G=abs(G);
% using log function for better visualization
subplot(222),imagesc(log(Mag_G))
title('log of the Magnitude of FT of the degraded noisy image'),colormap('gray'),daspect([1 1 1])

% Applying low pass filter on the degredation function before implementing
% the inverse filtering
% Butterworth Lowpass Filter
[M N]=size(H_d); % image size
% Gaussian Filter to apply inverse filter when std=0
[M N]=size(H_d); % image size
sigma1=40; % standard deviation 
X=0:M-1;
Y=0:N-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*M;
Cy=0.5*N;
LowPass_filter=exp(-((X-Cx).^2+(Y-Cy).^2)./(2*sigma1).^2);
LowPass_filter=fft2(LowPass_filter);
if (sigma==0)
  Filtered_H_d=(H_d).*LowPass_filter;
  Conj_Filtered_H_d=conj_H_d.*LowPass_filter;
else
  Filtered_H_d=(H_d);
  Conj_Filtered_H_d=conj_H_d;
end
% computing the power spectrum of the degredation function
Mag_Filtered_H_d=Conj_Filtered_H_d.*Filtered_H_d;
%the function of wiener filter
wiener_filter=((ones(size(Filtered_H_d))./Filtered_H_d).*(Mag_Filtered_H_d./(Mag_Filtered_H_d+Sn_Sf)));
subplot(223),imshow(20*log10(abs(wiener_filter)))
title('Magnitude of Wiener Filter='),colormap('gray'),daspect([1 1 1])
%}
% Fourier Transform of the Estimated Image
FI=G.*wiener_filter;
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% rescaling the output image to take values between 0 and 255
Filtered_image=rescale(Filtered_image,0,255);
%Displaying the filtered image
subplot(224),imagesc(Filtered_image)
title('Filtered Image by Wiener Filter'),colormap('gray'),daspect([1 1 1])
% Computing the RRMSE
diff_g_Input=zeros(W,H);
diff_Filtered_image_Input=zeros(W,H);
Input_Image_Square=zeros(W,H);
for i=1:W
    for j=1:H
    diff_g_Input(i,j)=(Input_Image(i,j)-Noisy_g(i,j))^2; 
    diff_Filtered_image_Input(i,j)=(Input_Image(i,j)-Filtered_image(i,j))^2; 
    Input_Image_Square(i,j)=(Input_Image(i,j))^2;
    end
end
RRMSE_g_Input=sqrt((sum(sum(diff_g_Input)))./(sum(sum(Input_Image_Square))));
RRMSE_Filtered_image_Input=sqrt((sum(sum(diff_Filtered_image_Input)))./(sum(sum(Input_Image_Square))));
RRMSE_g_Input_vector(1,counter)=RRMSE_g_Input;
RRMSE_Filtered_image_Input_vector(1,counter)=RRMSE_Filtered_image_Input;
counter=counter+1;
end
Std=[0,5,10,15,20,25];
% Plotting the RRMSE
figure
subplot(121),scatter(Std,RRMSE_g_Input_vector)
title('RRMSE of Degraded Image w.r.t original Image')
xlabel('Standard Deviation of the Gaussian Noise')
ylabel('RRMSE(Original, Degraded Image)')
subplot(122),scatter(Std,RRMSE_Filtered_image_Input_vector)
title('RRMSE of Filtered Image w.r.t original Image')
xlabel('Standard Deviation of the Gaussian Noise')
ylabel('RRMSE(Original, Filtered Image)')
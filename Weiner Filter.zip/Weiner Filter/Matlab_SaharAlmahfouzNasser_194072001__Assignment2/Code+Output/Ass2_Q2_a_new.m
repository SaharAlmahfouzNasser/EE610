% reading the input image
Input_Image=imread('image.png');
% convert the input image to gray image
Input_Image=rgb2gray(Input_Image);
Input_Image=double(Input_Image);
% displaying the input image
figure
subplot(221),imagesc(Input_Image)
title('Input Image'),colormap('gray'),daspect([1 1 1])
%Processing the input image in the frequency domain
[width,height]=size(Input_Image);
Input_Image_freq=zeros(size(Input_Image));
% multipling the input image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width
    for j=1:height
       k=i+j;
       Input_Image_freq(i,j)=Input_Image(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(Input_Image_freq);
% the magnitude of fourier transform
Mag=abs(F);
% using log function for better visualization
subplot(222),imagesc(20*log10(Mag))
title('log of the Magnitude of fourier transform of the original image'),colormap('gray'),daspect([1 1 1])
% Generating the degradation function in frequency domain
m=width/2;
n=height/2;
H_d=zeros(size(F));
for u=1:width
    for v=1:height
        % sbtracting m,n to center the spectrum
        i=sqrt(-1);
        H_d(u,v)=(1./(0.001+pi.*(0.1*(u-m)+0.1*(v-n))))*(0.001+sin(pi*(0.1*(u-m)+0.1*(v-n))))*exp(-i*pi*(0.1*(u-m)+0.1*(v-n)));
    end
end
Mag_H_d=abs(H_d);
% displaying the degradation function
subplot(223),imagesc(20*log10(Mag_H_d))
title('The Magnitude of FT of the Degredation Function'),colormap('gray'),daspect([1 1 1])
% Degrading the input image with the given degradation function
G=F.*H_d;
G=ifftshift(G);
% computing the inverse fourier transform
g=ifft2(G);
%extracting the real part
g=real(g);
subplot(224),imagesc(g)
title('The degraded image before adding the noise'),colormap('gray'),daspect([1 1 1])
% Maximum Intensity of the input image
Max=max(max(Input_Image));
% Intialization of relative root mean square error vectors
RRMSE_g_Input_vector=zeros(1,6);
RRMSE_Filtered_image_Input_vector=zeros(1,6);
counter=1;
for s=1:5:26
% Adding the gaussian noise
%sigma is the standard deviation of the gaussian noise 
sigma=((s-1)/100)*Max;
Noisy_g=g+sigma*randn(size(g));
Noisy_g=uint8(Noisy_g);
% Displaying the degraded image after adding the noise
figure
subplot(231),imagesc(Noisy_g)
title(['Degraded Image after adding gaussian noise with std=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])
%Computing fourier transform of the degraded image
[w,h]=size(Noisy_g);
g_n=zeros(size(Noisy_g));
% multipling g by -1^(i+j) in order to center the fourier 
%transform
for i=1:w
    for j=1:h
       k=i+j;
       g_n(i,j)=g(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
G=fft2(g_n);
[W,H]=size(G);
% the magnitude of fourier transform
Mag_G=abs(G);
% using log function for better visualization
subplot(232),imagesc(20*log10(Mag_G))
title(' Magnitude of FT of the degraded noisy image'),colormap('gray'),daspect([1 1 1])

% Applying low pass filter on the degredation function before implementing
% the inverse filtering
% Gaussian Filter
[M N]=size(H_d); % image size
sigma1=50; % standard deviation 
X=0:M-1;
Y=0:N-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*M;
Cy=0.5*N;
LowPass_filter=exp(-((X-Cx).^2+(Y-Cy).^2)./(2*sigma1).^2);
LowPass_filter=fft2(LowPass_filter);
%subplot(223),imshow(LowPass_filter)
%title(['Gaussian Low Pass Filter with sigma=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])
%Filtered_H_d=(ones(size(H_d))./H_d).*LowPass_filter;
Filtered_H_d=(H_d).*LowPass_filter;
subplot(234),imagesc(20*log10(abs((ones(size(H_d))./Filtered_H_d))))
title("the magnitude of inverse filter"),colormap('gray'),daspect([1 1 1])
subplot(233),imagesc(log(abs(Filtered_H_d)))
title(['Filtered degredation function by Gaussian LP filter with sigma=',num2str(sigma1)]),colormap('gray'),daspect([1 1 1])
%}
% Fourier Transform of the Estimated Image
[r,s]=size(Filtered_H_d);
Filtered_H_d_mod=zeros(size(Filtered_H_d));
%{
for u=1:r
for v=1:s
    if abs(Filtered_H_d(u,v))<=0.75*(abs(max(max(Filtered_H_d))))
       Filtered_H_d_mod(u,v)=Filtered_H_d(u,v) ;
    else
        Filtered_H_d_mod(u,v)=0;
    end
end
end
%}

Inverse_Filter=(ones(size(Filtered_H_d))./Filtered_H_d); 
FI=G.*Inverse_Filter;

% displaying the FT of the filtered image
subplot(235),imagesc(20*log10(abs(FI)))
title('Magnitude of the FT of the Filtered Image '),colormap('gray'),daspect([1 1 1])
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% rescaling the output image to take values between 0 and 255
Filtered_image=rescale(Filtered_image,0,255);
%Displaying the filtered image
subplot(236),imagesc(Filtered_image)
title('Filtered Image by Inverse Filter'),colormap('gray'),daspect([1 1 1])
% Computing the RRMSE
diff_g_Input=zeros(W,H);
diff_Filtered_image_Input=zeros(W,H);
Input_Image_Square=zeros(W,H);
for i=1:W
    for j=1:H
    diff_g_Input(i,j)=(Input_Image(i,j)-Noisy_g(i,j))^2; 
    diff_Filtered_image_Input(i,j)=(Input_Image(i,j)-Filtered_image(i,j))^2; 
    Input_Image_Square(i,j)=(Input_Image(i,j))^2;
    end
end
RRMSE_g_Input=sqrt((sum(sum(diff_g_Input)))./(sum(sum(Input_Image_Square))));
RRMSE_Filtered_image_Input=sqrt((sum(sum(diff_Filtered_image_Input)))./(sum(sum(Input_Image_Square))));
RRMSE_g_Input_vector(1,counter)=RRMSE_g_Input;
RRMSE_Filtered_image_Input_vector(1,counter)=RRMSE_Filtered_image_Input;
counter=counter+1;
end
Std=[0,5,10,15,20,25];
% Plotting the RRMSE
figure
subplot(121),scatter(Std,RRMSE_g_Input_vector)
title('RRMSE of Degraded Image w.r.t original Image')
xlabel('Standard Deviation of the Gaussian Noise')
ylabel('RRMSE(Original, Degraded Image)')
subplot(122),scatter(Std,RRMSE_Filtered_image_Input_vector)
title('RRMSE of Filtered Image w.r.t original Image')
xlabel('Standard Deviation of the Gaussian Noise')
ylabel('RRMSE(Original, Filtered Image)')
% reading the input image
q6=imread('q6.png');
figure
subplot(111),imagesc(q6)
title('Input Image'),colormap('gray'),daspect([1 1 1])

%Processing in the frequency domain
[width,height]=size(q6);
%padding the input image q3a to a size=2*original size
q6_pad_fre=padarray(q6,[width height],0,'post');
[width_pad,height_pad]=size(q6_pad_fre);


figure
subplot(221),imshow(q6_pad_fre)
title('the image after zero padding')
colormap('gray'),daspect([1 1 1])
q6_pad_fre_centered=zeros(size(q6_pad_fre));
% multipling the padded image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width_pad
    for j=1:height_pad
       k=i+j;
       q6_pad_fre_centered(i,j)=q6_pad_fre(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(q6_pad_fre_centered);
% the magnitude of fourier transform
Mag=abs(F);
% using log function for better visualization
subplot(222),imagesc(log(Mag))
title('log of the Magnitude of fourier transform'),colormap('gray'),daspect([1 1 1])

% Design the highpass filter


%%
%{
% Gaussian highpass Filter
[M N]=size(F); % image size
sigma=10; % standard deviation 
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
LowPass_filter=exp(-((X-Cx).^2+(Y-Cy).^2)./(2*sigma).^2);
HighPass_filter=1-LowPass_filter;

subplot(223),imshow(HighPass_filter)
title(['Gaussian High Pass Filter with sigma=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])
%}
%% Ideal High Pass Filter

% the cutoff frequecies
U=10;
V=10;
[width_I,height_I]=size(F);
Ideal_filter=zeros(size(F));
center_U=round(width_I./2);
center_V=round(height_I./2);
for i=center_U-U:center_U+U
    for j=center_V-V:center_V+V
        Ideal_filter(i,j)=1;
    end
end
Ideal_highpass_filter=1-Ideal_filter;
subplot(223),imshow(Ideal_highpass_filter)
title(['Ideal high Pass Filter with cutoff frequency=',num2str(U)]),colormap('gray'),daspect([1 1 1])
HighPass_filter=Ideal_highpass_filter;
%}
%% Butterworth
%{
[M N]=size(F); % image size
n=2; % Order of Butterworth Lowpass filter
D0=100;
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
LowPass_filter=1./(1+(((X-Cx).^(2*n)+(Y-Cy).^(2*n))./(D0.^(2*n))));
HighPass_filter=1-LowPass_filter;
subplot(223),imshow(HighPass_filter)
title(['Butterworth High Pass Filter with order=',num2str(n),'and D0=',num2str(D0)]),colormap('gray'),daspect([1 1 1])
%}

%%

% filtered image
FI=F.*HighPass_filter;
%removing the centering 
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% extracting the image
output=zeros(size(q6));
for i=1:width
    for j=1:height
        output(i,j)=Filtered_image(i,j);
    end
end
%display the image after filterring
subplot(224),imagesc(output)
title('Filtered Image'),colormap('gray'),daspect([1 1 1])
%}
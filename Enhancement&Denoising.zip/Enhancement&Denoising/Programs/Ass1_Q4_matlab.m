% reading the input image
q4=imread('q4.png');
%displaying the input image
figure
subplot(111),imagesc(q4)
title('Input Image'),colormap('gray'),daspect([1 1 1])

%filter size
W=3;
H=3;
size_F=W*H;
pad_W=round(W/2);
pad_H=round(H/2);
%padding the input image
q4_pad=padarray(q4,[pad_W pad_H],0,'both');
%the filter coefficients
%filter=[0,-1,0;-1,4,-1;0,-1,0];
filter=[-1,-1,-1;-1,8,-1;-1,-1,-1];
%filter=fspecial('laplacian')
filtered_image=imfilter(q4_pad,filter,'conv');
figure('Name','q4')
subplot(131),imshow(q4)
title('Input Image')
subplot(132),imshow(filtered_image)
title('Filtered Image using Laplacian in spatial Domain')
% sharpening the image g=f+C*Laplacian
C=1;
sharp_image=q4_pad+C*filtered_image;
subplot(133),imshow(sharp_image)
title('Filtered Image after sharpenning')
%Processing in the frequency domain
[width,height]=size(q4);
%padding the input image q3a to a size=2*original size
q4_pad_fre=padarray(q4,[width height],0,'post');
[width_pad,height_pad]=size(q4_pad_fre);
%q3a_pad_fre=im2double(q3a_pad_fre);

figure
subplot(221),imshow(q4_pad_fre)
title('the image after zero padding')
colormap('gray'),daspect([1 1 1])
q4_pad_fre_centered=zeros(size(q4_pad_fre));
% multipling the padded image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width_pad
    for j=1:height_pad
       k=i+j;
       q4_pad_fre_centered(i,j)=q4_pad_fre(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(q4_pad_fre_centered);
% the magnitude of fourier transform
Mag=abs(F);
% using log function for better visualization
subplot(222),imagesc(log(Mag))
title('log of the Magnitude of fourier transform'),colormap('gray'),daspect([1 1 1])

% Design the filter
[M N]=size(F); % image size
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
Laplacian=(-4*pi^2)*((X-Cx).^2+(Y-Cy).^2);

subplot(223),imagesc(log(abs(Laplacian)))
title('Laplacian Filter'),colormap('gray'),daspect([1 1 1])

% filtered image
FI=F.*Laplacian;
%removing the centering 
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% extracting the final image
output=zeros(size(q4));
for i=1:width
    for j=1:height
        output(i,j)=Filtered_image(i,j);
    end
end
%display the image after filterring
subplot(224),imagesc(output)
title('Filtered Image'),colormap('gray'),daspect([1 1 1])
%{
% sharpening the image g=f+C*Laplacian
C=1;
output=uint8(output);
sharp_image_freq=q4_pad+output;
%display the image after filterring
subplot(121),imagesc(output)
title('Filtered Image'),colormap('gray'),daspect([1 1 1])
subplot(133),imshow(sharp_image_freq)
title('Filtered Image after sharpenning')
%}
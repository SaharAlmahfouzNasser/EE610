% q3 filterring
%reading the images
q3a=imread('q3a.png');
q3b=imread('q3b.png');

% for image q3a as the noise is gaussian so using smoothing filter will give better results
%filter size
W=3;
H=3;
size_F=W*H;
pad_W=round(W/2);
pad_H=round(H/2);
%padding the input image
q3a_pad=padarray(q3a,[pad_W pad_H],0,'both');
%the filter coefficient
filter=(1/size_F)*ones(W,H);
% convolution
filtered_image=imfilter(q3a_pad,filter,'conv');
% displaying the input and the output images
figure('Name','q3a')
subplot(131),imshow(q3a)
title('Input Image')
subplot(132),imshow(filtered_image)
title(['output image -- mean filter -- filter size=',num2str(W),'*',num2str(H)])
% using gaussian filter instead of mean filter
sigma=2;
I= imgaussfilt(q3a_pad,sigma);
subplot(133),imshow(filtered_image)
title(['output image -- gaussian filter -- filter size=',num2str(W),'*',...
       num2str(H),'--sigma=',num2str(sigma),])
%Processing in the frequency domain
[width,height]=size(q3a);
%padding the input image q3a to a size=2*original size
q3a_pad_fre=padarray(q3a,[width height],0,'post');
[width_pad,height_pad]=size(q3a_pad_fre);
%q3a_pad_fre=im2double(q3a_pad_fre);

figure
subplot(221),imshow(q3a_pad_fre)
title('the image after zero padding')
colormap('gray'),daspect([1 1 1])
q3a_pad_fre_centered=zeros(size(q3a_pad_fre));
% multipling the padded image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width_pad
    for j=1:height_pad
       k=i+j;
       q3a_pad_fre_centered(i,j)=q3a_pad_fre(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(q3a_pad_fre_centered);
% the magnitude of fourier transform
Mag=abs(F);
% using log function for better visualization
subplot(222),imagesc(log(Mag))
title('log of the Magnitude of fourier transform'),colormap('gray'),daspect([1 1 1])
% Design the filter
[M N]=size(F); % image size
sigma=50; % standard deviation 
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
LowPass_filter=exp(-((X-Cx).^2+(Y-Cy).^2)./(2*sigma).^2);
%displaying the filter
subplot(223),imshow(LowPass_filter)
title(['Gaussian Low Pass Filter with sigma=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])

% filtered image
FI=F.*LowPass_filter;
%removing the centering 
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% extracting the image
output=zeros(size(q3a));
for i=1:width
    for j=1:height
        output(i,j)=Filtered_image(i,j);
    end
end
%display the image after filterring
subplot(224),imagesc(output)
title('Filtered Image'),colormap('gray'),daspect([1 1 1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% q3 part b
%reading the input image
q3b=imread('q3b.png');
%displaying the input image
figure
subplot(121),imagesc(q3b)
title('Input Image'),colormap('gray'),daspect([1 1 1])
% as the noise is salt and pepper noise so median filter is better
% size of the window
m=3;
n=3;
Output_image=medfilt2(q3b,[m n]);
subplot(122),imagesc(Output_image)
title('Filtered Image--Median Filter'),colormap('gray'),daspect([1 1 1])






% Image Processing Assignment 1
% First question
% reading the input image
q1=imread('q1.png');
% displaying the input image
figure('Name','q1')
subplot(121),imshow(q1)
title('Input Image')
%displaying the histogram of the input image
subplot(122),imhist(q1)
title('the histogram of the Input Image')
figure('Name','q1:Log Transformation')
subplot(131),imshow(q1)
title('Input Image')
q1=double(q1);
% C is the hyperparameter (a constant)
C=5;
% applying the log transformation
q1_out=C*log10(1+q1);
%}
% Normalizing the output
Min=min(min(q1_out))
Max=max(max(q1_out))
q1_out_norm_log=((q1_out-Min)/(Max))*255;
% displaying the result of the log transformation
subplot(132),imshow(q1_out_norm_log);
title(['The result of applying Log transformation:C=',num2str(C)])
% computing the inverse logarithmic transformation
q1_out=10.^q1_out;
%normalizing
Min=min(min(q1_out));
Max=max(max(q1_out));
q1_out_norm_anti=((q1_out-Min)/Max)*255;
% displaying the result of the antilog transformation
subplot(133),imshow(q1_out_norm_anti);
title(['The result of applying antilog transformation:C=',num2str(C)])
% q2 Histogram Equalization
% reading the input image
q2=imread('q2.png');

% displaying the input image
figure('Name','q2 Histogram Equalization')
subplot(131),imshow(q2)
title('Input Image')
% Global Histogram equalization
GH=histeq(q2);
% Displaying the output of histogram equalization
subplot(132),imshow(GH)
title('Global Histogram Equalization output Image')
% window size
H=3;
W=3;
window=zeros(W,H);
% padding the input image
pad_W=round(W-1/2);
pad_H=round(H-1/2);
q2_pad=padarray(q2,[pad_W pad_H],0,'both');
% Local Histogram Equalization 
% Intialization of the output image
LHE_image=zeros(size(q2_pad));
[width,height]=size(LHE_image);
W_mid=floor(W/2);
H_mid=floor(H/2);
for i=1+W_mid:width-W_mid
    for j=1+H_mid:height-H_mid
        for x=-W_mid:W_mid
            for y=-H_mid:H_mid
                window(x+W_mid+1,y+H_mid+1)=q2_pad(i+x,j+y);
            end
        end
        w_eq=histeq(window);
        LHE_image(i,j)=w_eq(W_mid+1,H_mid+1);
        window=zeros(size(window));
    end
end
%{
Normalization
Min=min(min(LHE_image));
Max=max(max(LHE_image));
LHE_image=((LHE_image-Min)/Max)*255;
%}
% Displaying the output of the local histogram equalization
subplot(133),imshow(LHE_image)
title(['LHE output with window size=',num2str(W),'*',num2str(H)])


% reading the input image
q5=imread('q5.png');
% displaying the input image
figure
subplot(111),imagesc(q5)
title('Input Image'),colormap('gray'),daspect([1 1 1])

%Processing in the frequency domain
[width,height]=size(q5);
%padding the input image q3a to a size=2*original size
q5_pad_fre=padarray(q5,[width height],0,'post');
[width_pad,height_pad]=size(q5_pad_fre);
%displaying the padded image
figure
subplot(221),imshow(q5_pad_fre)
title('the image after zero padding')
colormap('gray'),daspect([1 1 1])
q5_pad_fre_centered=zeros(size(q5_pad_fre));
% multipling the padded image by -1^(i+j) in order to center the fourier 
%transform
for i=1:width_pad
    for j=1:height_pad
       k=i+j;
       q5_pad_fre_centered(i,j)=q5_pad_fre(i,j).*(-1).^k;
       k=0;
    end
end
% computing the fourier transform of the result of the previous step
F=fft2(q5_pad_fre_centered);
% the magnitude of fourier transform
Mag=abs(F);
% using log function for better visualization
subplot(222),imagesc(log(Mag))
title('log of the Magnitude of fourier transform'),colormap('gray'),daspect([1 1 1])

% Design the filter
%%
%{
% Gaussian Filter
[M N]=size(F); % image size
sigma=70; % standard deviation 
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
LowPass_filter=exp(-((X-Cx).^2+(Y-Cy).^2)./(2*sigma).^2);

subplot(223),imshow(LowPass_filter)
title(['Gaussian Low Pass Filter with sigma=',num2str(sigma)]),colormap('gray'),daspect([1 1 1])
%}
%% Ideal Low Pass Filter
%{
% the cutoff frequecies
U=300;
V=300;
[width_I,height_I]=size(F);
Ideal_filter=zeros(size(F));
center_U=round(width_I./2);
center_V=round(height_I./2);
for i=center_U-U:center_U+U
    for j=center_V-V:center_V+V
        Ideal_filter(i,j)=1;
    end
end

subplot(223),imshow(Ideal_filter)
title(['Ideal Low Pass Filter with cutoff frequency=',num2str(U)]),colormap('gray'),daspect([1 1 1])
LowPass_filter=Ideal_filter;
%}
%% Butterworth

[M N]=size(F); % image size
n=1.5; % Order of Butterworth Lowpass filter
D0=200;
X=0:N-1;
Y=0:M-1;
[X Y]=meshgrid(X,Y);
Cx=0.5*N;
Cy=0.5*M;
LowPass_filter=1./(1+(((X-Cx).^(2*n)+(Y-Cy).^(2*n))./(D0.^(2*n))));
subplot(223),imshow(LowPass_filter)
title(['Butterworth Low Pass Filter with order=',num2str(n),'and D0=',num2str(D0)]),colormap('gray'),daspect([1 1 1])
%}

%%
% filtered image
FI=F.*LowPass_filter;
%removing the centering 
FI_new=ifftshift(FI);
% computing the inverse fourier transform
Result=ifft2(FI_new);
%extracting the real part
Filtered_image=real(Result);
% extracting the image
output=zeros(size(q5));
for i=1:width
    for j=1:height
        output(i,j)=Filtered_image(i,j);
    end
end
%display the image after filterring
subplot(224),imagesc(output)
title('Filtered Image'),colormap('gray'),daspect([1 1 1])
%}